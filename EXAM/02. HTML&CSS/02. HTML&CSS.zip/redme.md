Ползвам Fire Fox browser. Имах проблем с live server при тази задача, и съм ползвал друг.
